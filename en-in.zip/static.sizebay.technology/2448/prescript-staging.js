const __lang = () => document.querySelector('html')?.lang.replace('ja', 'jp')
const __prodSlug = () => document.querySelector('div.pdp-info__sku-message')?.textContent.split(' ').pop()

const __ids = [
  'F8N50TFUEEYW0800',
  'GY07LDG8GM3S9001',
  'F29NITFUBAJN0000',
  'F756QTFUGFJN0000',
  'F8N51TFUGFJN0000',
  'BI1398AW07080999',
  'F756GTFLSA8S0998',
  'F4CFLTHS5NNHA3VN',
  'F7W98TFSEHVHA3VN',
  'F4A8QTHS5M4HA3QF',
  'F4CFCTHS5NHHA3VL',
  'F4B7RTFJTBPN0000',
  'F6ARVTFMMHNF0758',
  'F4CB1THS5M5HA3QG',
]

const __szbTexts = {
  en: {
    buttons: {
      chart: 'Size guide',
      vfr: 'Discover your size',
    },
    recommendation: {
      default: '{profileName} your size is <b>{size} Discover more</b>',
      simplified: 'Your size is <b>{size}  Discover more</b>',
    },
  },
  es: {
    buttons: {
      chart: 'Guía de tallas',
      vfr: 'Descubre tu talla',
    },
    recommendation: {
      default: '{profileName} Tu talla es la <b>{size} ¡Descubre más</b>',
      simplified: 'Tu talla es la<b>{size} ¡Descubre más</b>',
    },
  },
  fr: {
    buttons: {
      chart: 'Guide des tailles',
      vfr: 'Découvrez votre taille',
    },
    recommendation: {
      default: '{profileName} Votre taille est <b>{size} En savoir plus</b>',
      simplified: 'Votre taille est <b>{size} En savoir plus</b>',
    },
  },
  de: {
    buttons: {
      chart: 'Größen-leitfaden',
      vfr: 'Entdecken Sie Ihre Größe',
    },
    recommendation: {
      default: '{profileName} Ihre Größe ist <b>{size} Entdecken Sie mehr</b>',
      simplified: 'Ihre Größe ist <b>{size} Entdecken Sie mehr</b>',
    },
  },
  ko: {
    buttons: {
      chart: '사이즈 안내',
      vfr: '사이즈 알아보기',
    },
    recommendation: {
      default: '{profileName} 귀하의 사이즈는 <b>{size} 입니다. 자세히 알아보기</b>',
      simplified: '귀하의 사이즈는 <b>{size} 입니다. 자세히 알아보기</b>',
    },
  },
  jp: {
    buttons: {
      chart: 'サイズガイド',
      vfr: 'あなたのサイズを発見',
    },
    recommendation: {
      default: '{profileName} あなたのサイズは <b>{size} もっと見つけてください</b>',
      simplified: 'あなたのサイズは <b>{size}</b> もっと見つけてください',
    },
  },
  zh: {
    buttons: {
      chart: '尺码指南',
      vfr: '发现你的尺寸',
    },
    recommendation: {
      default: '{profileName} 您的尺码是 <b>{size} 发现更多</b>',
      simplified: '您的尺码是 <b>{size} 发现更多</b>',
    },
  },
  ar: {
    buttons: {
      chart: 'دليل المقاسات',
      vfr: 'اكتشف حجمك',
    },
    recommendation: {
      default: '<b>{size}</b> مقاسك هو {profileName} اكتشف المزيد',
      simplified: 'حجمك <b>{size}</b> اكتشف المزيد',
    },
  },
  ru: {
    buttons: {
      chart: 'Гид по размерам',
      vfr: 'Узнайте свой размер',
    },
    recommendation: {
      default: 'Ваш размер <b>{size} Узнайте больше</b>',
      simplified: 'Ваш разме <b>{size} Узнайте больше</b>',
    },
  },
  it: {
    buttons: {
      chart: 'Guida alle taglie',
      vfr: 'Scopri la tua taglia',
    },
    recommendation: {
      default: '{profileName} La tua taglia è <b>{size} Scopri di più</b>',
      simplified: 'La tua taglia è <b>{size} Scopri di più</b>',
    },
  },
}

const __translations = () => {
  switch (__lang()) {
    case 'en':
      return __szbTexts.en
    case 'ko':
      return __szbTexts.ko
    case 'jp':
      return __szbTexts.jp
    case 'zh':
      return __szbTexts.zh
    case 'ar':
      return __szbTexts.ar
    case 'ru':
      return __szbTexts.ru
    case 'it':
      return __szbTexts.it
    case 'de':
      return __szbTexts.de
    case 'fr':
      return __szbTexts.fr
    case 'es':
      return __szbTexts.es
    default:
      return __szbTexts.en
  }
}

const __cartHandler = (size, quantity) => {
  const container =
    window.innerWidth && document.querySelectorAll('h3.b-slide-flyout_title').length > 0 < 768
      ? 'div.b-variation-item.js-open-size-flyout'
      : '#sizebay-container'
  try {
    document.querySelector(container)?.click()
  } catch (error) {
    console.error(`An error occurred: ${error.message}`)
  } finally {
    console.log('Finished function')
  }
}

const eventsObject = {
  onAddToCart: ({ size, quantity }) => {
    __cartHandler(size, quantity)
  },
  onProductFound: () => {
    document.dispatchEvent(new Event('sizeBayProductFound'))
    dataLayer.push({ event: 'sizeBayProductFound' })
  },
}

const __clearSizebay = () => {
  const selectors = ['link.szb__styles', 'div.vfr__container', 'div.szb-container__hide']

  for (const element of selectors) {
    if (document.querySelectorAll(element).length) {
      document.querySelector(element).remove()
    }
  }
}

const __moveSizebay = () => {
  const szbContainer = document.querySelectorAll('div.szb-container__hide > div.vfr__container')

  if (szbContainer.length) {
    const anchor = document.querySelector('h3.FlyoutSizeSelector__size-selector__title--OdLQq')
    const sizePanel = document.querySelector('div.flyout__wrapper--after-open')

    if (sizePanel?.querySelectorAll('.vfr__container').length) sizePanel?.querySelector('.vfr__container')?.remove()

    anchor?.after(szbContainer[0]?.cloneNode(true))

    sizePanel
      .querySelector(' #szb-vfr-button')
      .addEventListener('click', () => szbContainer[0].querySelector('#szb-vfr-button')?.click())
    sizePanel
      .querySelector('#szb-chart-button')
      .addEventListener('click', () => szbContainer[0].querySelector('#szb-chart-button')?.click())
  }
}

const __createSizebayElement = () => {
  const container = document.createElement('div')
  container.setAttribute('class', 'szb-container__hide')

  document.querySelector('span[class*="ProductStrip__product__strip__size__cta--"]').append(container)
}

window.SizebayPrescript = () => ({
  getPermalink() {
    return `https://www.dolcegabbana.com/product/${__prodSlug()}`
  },
  getAnchor() {
    return {
      web: 'h3.FlyoutSizeSelector__size-selector__title--OdLQq',
      mobile: 'h3.FlyoutSizeSelector__size-selector__title--OdLQq',
    }
  },
  getTenantId() {
    const difTenant = __ids.find((id) => __prodSlug()?.includes(id))
    if (difTenant) return 24482448

    return 2448
  },
  getButtons() {
    return {
      order: [
        {
          name: 'vfr',
          text: null,
          customHTML: `
            <div class="div-span">
              <span class="sizebay-text-decorate">${__translations().buttons.vfr}</span>
            </div>
          `,
        },
        { name: 'chart', text: __translations().buttons.chart },
      ],
      position: 'after',
      class: 'vfr__button--clean',
    }
  },
  getLanguage() {
    return __lang()
  },
  getRecommendationText() {
    return {
      ...__translations().recommendation,
      order: 'prepend',
      anchor: '#szb-vfr-button',
    }
  },
  hasOnPageIntegration() {
    return __lang() === 'en' && window.innerWidth > 768
  },
  getProductSizes() {
    return [...document.querySelectorAll('.flyout__content li span')]
      .map((el) => el.textContent.split(' ').join('').trim().split('Pre-order').join(''))
      .filter((el) => !!el)
  },
})

const insertScript = (ref) => {
  const app = document.createElement('script')
  app.id = 'szb-vfr__base'
  app.setAttribute('src', ref)
  document.head.appendChild(app)
}

const sizebayStyles = (ref) => {
  const linkElem = document.createElement('link')
  linkElem.setAttribute('class', 'szb__styles')
  linkElem.setAttribute('rel', 'stylesheet')
  linkElem.setAttribute('type', 'text/css')
  linkElem.setAttribute('href', ref)

  document.head.appendChild(linkElem)
}

function createCustomStyle() {
  const styles = [
    `https://static.sizebay.technology/2448/styles${__lang().includes('ar') ? 'AR_v4' : '_v4New'}.css`,
    'https://static.sizebay.technology/font/stores/fontRuler/styles.css',
  ]

  for (const iterator of styles) {
    sizebayStyles(iterator)
  }
}

const sizebayImplantation = () => {
  insertScript('https://vfr-v3-production.sizebay.technology/V4/implantation/index.js')
}

function SizebayInit() {
  __clearSizebay()
  createCustomStyle()

  const payload = {
    permalink: SizebayPrescript().getPermalink(),
    tenantId: SizebayPrescript().getTenantId(),
    buttons: SizebayPrescript().getButtons(),
    anchor: SizebayPrescript().getAnchor(),
    lang: SizebayPrescript().getLanguage(),
    recommendation: SizebayPrescript().getLanguage(),
  }

  window.addEventListener('sizebay:rendered', () => {
    document.querySelector('div.FlyoutSizeSelectorAction__flyout-size-selector__actions-wrapper--WYssA')?.remove()
  })

  const sizebayRender = () => {
    console.log(`Sizebay -> produto: ${payload.permalink}`)
    window?.Sizebay?.Implantation(payload, eventsObject)
  }

  if (typeof window?.Sizebay?.Implantation !== 'function') {
    window.addEventListener('sizebay:loaded', () => {
      if (!document.querySelectorAll('.vfr__container').length) sizebayRender()
    })

    return
  }

  sizebayRender()
}

// window.addEventListener('message', (event) => {
//   if (event?.data === 'szb:recommendation-done') {
//     document.querySelectorAll('div.flyout__wrapper--after-open').length > 0 && __moveSizebay()
//   }
// })

const firstOpeningListener = () => {
  const target = document.querySelector('body')

  const observer = new MutationObserver(function (mutations) {
    mutations.forEach(function (mutation) {
      if (mutation?.addedNodes[0]?.className?.includes('FlyoutSizeSelectorActions__flyout-size-selector__actions--')) {
        SizebayInit()

        observer.disconnect()
      }
    })
  })

  const config = { subtree: true, attributes: true, childList: true }

  observer.observe(target, config)
}

const szbObserver = () => {
  const target = document.querySelector('html')

  const observer = new MutationObserver(function (mutations) {
    mutations.forEach(function (mutation) {
      if (
        mutation?.target?.classList?.value.includes('lock-scroll') ||
        document.querySelectorAll('div.flyout__overlay--after-open')?.length
      ) {
        if (
          !document.querySelectorAll('div.flyout__overlay--after-open div.vfr__container').length &&
          document.querySelectorAll('div.FlyoutSizeSelector__size-selector__title-wrapper--P2T0Z').length
        ) {
          // __moveSizebay()
          SizebayInit()
        }
      }
    })
  })

  const config = { classList: true, attributes: true }

  observer.observe(target, config)
}

const szbObserverLang = () => {
  const target = document.querySelector('html')

  const observer = new MutationObserver(function (mutations) {
    mutations.forEach(function (mutation) {
      if (mutation?.attributeName === 'lang') {
        if (mutation?.target?.lang !== mutation?.oldValue) {
          __clearSizebay()

          SizebayInit()
        }
      }
    })
  })

  const config = { attributes: true, attributeOldValue: true }

  observer.observe(target, config)
}

const loaded = setInterval(() => {
  if (document.querySelectorAll('span[class*="ProductStrip__product__strip__size__cta--"]').length) {
    sizebayImplantation()

    firstOpeningListener()
    szbObserver()

    clearInterval(loaded)
  }
}, 100)